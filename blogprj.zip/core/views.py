from django.shortcuts import render, get_object_or_404,redirect
from .models import Post,Category
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import PostForm
# from django
# Create your views here.

def Home(request):
    featured = Post.objects.filter(featured=True,status='approved').order_by('-id')[:1]
    trending = Post.objects.filter(trending=True, status='approved').order_by('-id')[:4]
    post = Post.objects.all().order_by('-id')[:7]
    # user = u
    context ={
        'featureds':featured,
        'trending':trending,
        'posts':post
    }
    return render(request, 'core/index.html' ,context)


def PostDetails(request, pk):
    post = get_object_or_404(Post, pk=pk)
    context={
        'post':post
    }
    return render(request, 'core/single-blog.html', context)
def About(request):
    return render(request, 'core/about.html')

@login_required
def Create_Post(request):
    form = PostForm
    categories = Category.objects.all()
    context={
        "form":form, 
         "categories": categories
    }
    if request.method =="POST":
        form = form(request.POST, request.FILES )
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return redirect('home')
    else:
        form = PostForm()
        print(messages.error)
    return render(request, "core/create.html",context)
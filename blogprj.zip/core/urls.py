from django.urls import path

from .  import views

urlpatterns = [
    path('', views.Home, name='home'),
    path('about/', views.About, name='about'),
    path('post/create/', views.Create_Post, name="create"),
    path('post-details/<int:pk>/', views.PostDetails, name='post-details')
]
